from aiogram import Bot, Dispatcher, executor, types
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.types.web_app_info import WebAppInfo

API_TOKEN = '6674548712:AAGcfnbjNOL16ZcPuB1tOb7STzTcdFoCP50'

bot = Bot(token=API_TOKEN)
dp = Dispatcher(bot)

@dp.message_handler(commands="start")
async def cmd_start(message: types.Message):
    await message.answer("test", 
        reply_markup=InlineKeyboardMarkup().add(InlineKeyboardButton(text="test", 
        web_app=WebAppInfo(url="https://24jaser.ru:5555/"))))

if __name__ == '__main__':
    executor.start_polling(dp, skip_updates=True)